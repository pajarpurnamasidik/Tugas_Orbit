# Snake-AI-Based-on-RL

This project proposed to be the basic step to enter Reinforcement Learning. 


![image](https://user-images.githubusercontent.com/34513519/150244873-67edfb51-7665-42ea-a513-ce730413c882.png)


## How to use:

1. Install Conda Environment 
2. Install Depedency by | pip install -r requirements.txt |
3. Train and Run the Snake | python agents.py | 